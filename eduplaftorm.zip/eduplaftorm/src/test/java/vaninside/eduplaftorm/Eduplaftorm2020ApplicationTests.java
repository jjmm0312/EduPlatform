package vaninside.eduplaftorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eduplaftorm2020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
