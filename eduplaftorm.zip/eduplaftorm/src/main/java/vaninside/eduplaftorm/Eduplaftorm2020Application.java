package vaninside.eduplaftorm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eduplaftorm2020Application {

	public static void main(String[] args) {
		SpringApplication.run(Eduplaftorm2020Application.class, args);
	}

}
